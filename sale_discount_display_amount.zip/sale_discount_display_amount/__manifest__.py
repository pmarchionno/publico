# Copyright 2018 ACSONE SA/NV
# Copyright 2026 Hito Fusion - Fix for Odoo 17
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

{
    "name": "Sale Discount Display Amount",
    "summary": """
        This addon intends to display the amount of the discount computed on
        sale_order_line and sale_order level""",
    "version": "17.0.1.1.2",
    "license": "AGPL-3",
    "author": "ACSONE SA/NV, Odoo Community Association (OCA), Hito Fusion",
    "website": "https://github.com/OCA/sale-workflow",
    "depends": ["sale_management"],
    "data": [
        "views/res_config_settings_views.xml",
        "views/sale_view.xml",
        "report/sale_report_template.xml",
    ],
    "pre_init_hook": "pre_init_hook",
    "post_init_hook": "post_init_hook",
}
